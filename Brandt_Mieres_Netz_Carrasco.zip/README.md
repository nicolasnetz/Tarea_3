# Tarea 3

Autores:
    - Benjamín Enrique Brandt Mieres
    - Nicolás Eduardo Netz Carrasco

Profesor:
    - Carlos Contreras Bolton

Referencias:
 - # MODELO MTZ
    Miller, Tucker y Zemlin (MTZ) (1960)

 - # MODELO TCF
  Langevin, A., Desrochers, M., Desrosiers, J., Gélinas, S., & Soumis, F. (1993). A two-commodity flow formulation for the traveling salesman and the makespan problems with time windows.

 - # OTROS
  Pérez de Vargas Moreno, B. (2015) .Resolución del Problema del Viajante de Comercio (TSP) y su variante con Ventanas de Tiempo (TSPTW) usando métodos heurísticos de búsqueda local .

  Solomon, M. M., (1984), Vehicle routing and scheduling with time window contraints: Models and algorithms
  
  Pacheco, J. (2002). Problemas de rutas con ventanas de tiempo